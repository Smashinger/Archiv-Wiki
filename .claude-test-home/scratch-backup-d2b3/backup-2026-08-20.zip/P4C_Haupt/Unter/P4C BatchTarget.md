---
title: P4C BatchTarget
tags: []
category: Unter
mainCategory: P4C_Haupt
created: '2026-08-20T16:42:05.864Z'
modified: '2026-08-20T16:42:13.441Z'
archived: true
archivedAt: '2026-08-20T16:42:13.440Z'
---
Für D2-Batch-Regression.
