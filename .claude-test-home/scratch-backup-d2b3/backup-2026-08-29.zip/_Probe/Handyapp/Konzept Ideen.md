---
title: Konzept / Ideen
tags: [software]
category: Handyapp
mainCategory: _Probe
created: '2026-08-15T12:00:00.000Z'
modified: '2026-08-15T12:00:00.000Z'
---
# Idee

Idee pruefen — Was soll die App genau koennen? Wer ist die Zielgruppe?