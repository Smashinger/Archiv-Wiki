---
title: 02_Modelle
tags: [ki, linux]
category: Grundlagen
mainCategory: _Probe
created: '2026-08-12T12:00:00.000Z'
modified: '2026-08-12T12:00:00.000Z'
---
# Modelle

KI-Modelle Ein KI-Modell ist die trainierte Grundlage.