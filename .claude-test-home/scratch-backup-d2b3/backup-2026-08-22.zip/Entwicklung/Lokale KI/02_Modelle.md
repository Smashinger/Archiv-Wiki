---
title: 02_Modelle
tags:
  - ki
category: Lokale KI
mainCategory: Entwicklung
created: '2026-08-21T22:32:22.930Z'
modified: '2026-08-21T22:32:22.932Z'
---
KI-Modelle: Ein KI-Modell ist die trainierte Grundlage für Sprachverarbeitung.
