---
title: 01_Installation
tags:
  - linux
  - installation
category: Linux
mainCategory: Anleitungen
created: '2026-08-21T22:32:22.945Z'
modified: '2026-08-21T22:32:22.946Z'
---
Installation, Schritt für Schritt.
