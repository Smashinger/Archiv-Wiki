---
title: 00_Startseite
tags: [ki, linux]
category: LOKALE KI
mainCategory: _Probe
created: '2026-08-29T18:00:00.000Z'
modified: '2026-08-29T18:00:00.000Z'
---
# Start

KI & Softwareentwicklung — Willkommen im Handbuch mit einem laengeren Einleitungstext.