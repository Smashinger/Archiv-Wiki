---
title: Fedora Gaming Setup
tags: [linux, installation, software]
category: Linux
mainCategory: _Probe
created: '2026-08-27T12:00:00.000Z'
modified: '2026-08-27T12:00:00.000Z'
pinned: true
---
# Fedora

Komplette Anleitung fuer die Einrichtung von Spielen auf Fedora Linux.