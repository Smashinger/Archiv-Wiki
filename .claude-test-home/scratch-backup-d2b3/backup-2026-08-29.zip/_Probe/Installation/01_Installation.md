---
title: 01_Installation
tags: [installation, linux, software]
category: Installation
mainCategory: _Probe
created: '2026-08-10T12:00:00.000Z'
modified: '2026-08-10T12:00:00.000Z'
---
# Installation

Installation Lesezeit ca 3 Minuten in diesem Kapitel.