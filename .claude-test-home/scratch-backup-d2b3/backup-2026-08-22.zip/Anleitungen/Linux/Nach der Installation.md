---
title: Nach der Installation
tags:
  - linux
  - software
category: Linux
mainCategory: Anleitungen
created: '2026-08-21T22:32:22.941Z'
modified: '2026-08-21T22:32:22.943Z'
---
System-Setup-Übersicht, minimalistische Übersicht aller Tools.
