---
title: P4C Special
tags:
  - C++
  - foo/bar
  - <test>
  - Ümlaut-Söße
  - >-
    P4C-LangLangLangLangLangLangLangLangLangLangLangLangLangLangLangLangLangLangLangLang
category: Unter
mainCategory: P4C_Haupt
created: '2026-08-20T16:42:05.863Z'
modified: '2026-08-20T16:42:05.863Z'
---
Sonderzeichen-Notiz.
