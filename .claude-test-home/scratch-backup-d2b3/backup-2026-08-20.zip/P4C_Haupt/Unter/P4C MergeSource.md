---
title: P4C MergeSource
tags:
  - P4C-MergeTarget
category: Unter
mainCategory: P4C_Haupt
created: '2026-08-20T16:42:05.864Z'
modified: '2026-08-20T16:42:10.932Z'
---
Für Merge (Quelle).
