---
title: Neue Notiz
tags: []
category: Unterkategorie
mainCategory: Test
created: '2026-08-23T12:16:39.716Z'
modified: '2026-08-23T12:16:39.716Z'
---
# Neue Notiz

> [!abstract] Zusammenfassung
> Kurz worum es geht.

## Voraussetzungen

- 

## Schritte

1. 
2. 

## Troubleshooting

- **Problem:** 
  **Lösung:** 
