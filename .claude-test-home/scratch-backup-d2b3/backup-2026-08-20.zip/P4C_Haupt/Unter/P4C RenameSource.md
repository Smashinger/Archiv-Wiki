---
title: P4C RenameSource
tags:
  - P4C-RenameMe
category: Unter
mainCategory: P4C_Haupt
created: '2026-08-20T16:42:05.863Z'
modified: '2026-08-20T16:42:09.682Z'
---
Für Rename+Undo.
