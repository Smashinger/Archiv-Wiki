---
title: Nach der Installation mit einem ausgesprochen langen Titel der wirklich abgeschnitten werden muss
tags: [installation, linux]
category: Eine ausgesprochen lange Kategoriebezeichnung zum Test der Ellipsis und des Overflows
mainCategory: _Probe
created: '2026-08-26T12:00:00.000Z'
modified: '2026-08-26T12:00:00.000Z'
---
# Nach der Installation

System-Setup-Uebersicht minimalistische Uebersicht aller Tools und noch mehr Text zum Fuellen der Vorschau.